python3 tests/integrations/pg-mdm/time/audit.py pgreact:clone-candidate clone-evidence/full 
